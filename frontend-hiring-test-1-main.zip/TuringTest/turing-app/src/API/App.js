import axios from 'axios';
// const axios=require('axios').default;
const api=axios.create({
    baseURL:"https://frontend-test-api.aircall.io",
    headers:{
        'Content-Type':'application/json'
    }
    ,
    withCredentials:true
})


export const login=async (userData)=>{
    let response;
    try{

      response=await api.post('/auth/login',userData)
    }
  catch(err){
      console.log(err)
  }
  return response;  
}
///calls?offset=<number>&limit=<number>
export const getCalls=async (callsData,jwtToken)=>{
    let response;
    try{

      response=await api.get('/calls',{
            
            headers:{
                Authorization: `Bearer ${jwtToken}`,
            },
            params:{
                offset:callsData.offset,
                limit:callsData.limit,

                
            }
        
      })
    }
    catch(err){
        console.log(err)
    }

    return response;  
}

export const getMe=async (jwtToken)=>{
    let response;
    try{

      response=await api.get('/me',{
            headers:{
                Authorization: `Bearer ${jwtToken}`,
            }
        
      })
    }
  catch(err){
      console.log(err)
  }
  return response;  
}



export const addNotesofCall=async (id,note,jwtToken)=>{
    console.log(jwtToken)
    let response;
    try{
      response=await api.post(`/calls/${id}/note`,
      {
            content:note
      },
      { 
                headers:{
                    Authorization: `Bearer ${jwtToken}`,
                    'Content-Type': 'application/json' 
                },        
      }
      )
    }
  catch(err){
      console.log(err)
  }
  return response;  
}

export const RefreshToken = async (jwtToken) => {
    let response;
    try {
      response = await api.post(
        '/auth/refresh-token',
        {},
        {
          headers: {
            Authorization: `Bearer ${jwtToken}`,
          },
        }
      );
    } catch (err) {
      console.log(err.response);
    }
    return response;
  };


///calls/:id/archive
export const addArchive=async (id,jwtToken)=>{
    console.log(jwtToken)
    let response;
    try{
        //'/calls/:id/note'
      response=await api.put(`/calls/${id}/archive`,
      {
            
      },
      { 
                headers:{
                    Authorization: `Bearer ${jwtToken}`,
                    'Content-Type': 'application/json' 
                },        
      }
      )
    }
  catch(err){
      console.log(err)
  }
  return response;  
}





//Testing Purposes
// (async () => {

//     // id="8dac6b36-c3e0-4a93-bfd8-603ffb253120"
//     // note="hello waqas"
//     // //login 
//     // const userData={
//     //     username:"waqas",
//     //     password:"waqas"
//     // }
//     // const loginResponse=await login(userData)
//     // console.log(loginResponse.data)
//     //if successfull login




//     // if (loginResponse.data!=undefined){
//     //     const jwtToken=loginResponse.data.accessToken

//     //     console.log(jwtToken)
//         //get calls
//         // const callsData={
//         //     offset:0,
//         //     limit:10
//         // }
//         // const callsResponse=await getCalls(callsData,jwtToken)
//         // id=callsResponse.data.data[0].id
//         // //get me
//         // // const meResponse=await getMe(jwtToken)
    
//         // // //add notes
//         jwtToken="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJcIndhcWFzXCIiLCJ1c2VybmFtZSI6Ilwid2FxYXNcIiIsImlhdCI6MTY4NzAwOTkzNiwiZXhwIjoxNjg3MDEwNTM2fQ.o-lF_MyLmCzi5gXL1uedfj0TaT8vsXRZGrVh13RgoN4"
//         const addArchiveResponse=await addArchive("11528a0f-27c6-41fb-9257-932b04939644",jwtToken)
//         console.log(addArchiveResponse.data)
//         // const addNotesResponse=await addNotesofCall("11528a0f-27c6-41fb-9257-932b04939644","hello",jwtToken)
//         // console.log(addNotesResponse.data)
//         // console.log(callsResponse.data)
    
//         // accessToken="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJcIndhcWFzXCIiLCJ1c2VybmFtZSI6Ilwid2FxYXNcIiIsImlhdCI6MTY4NzAwODU0NCwiZXhwIjoxNjg3MDA5MTQ0fQ.pIqsXdQ-6MUmewXZprhBx3yBrdpgP2wfXUn0jLdFeTM"
//         // const tokens = await RefreshToken(accessToken)
//         // console.log(tokens);
    
//     // }
  
//   })();