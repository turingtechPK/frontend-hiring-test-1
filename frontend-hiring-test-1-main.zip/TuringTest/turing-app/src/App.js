import logo from './logo.svg';
import './App.css';
import Header from './components/Header/Header';
import Login from './components/Login';
import { Typography, AppBar, CssBaseline } from '@mui/material'
import { useSelector } from 'react-redux'
import { useState } from 'react';
import DisplayPage from './components/Calls/DisplayPage';

function App() {
  const isAuth = useSelector(state => state.auth.isAuth);
  return (
    <>
      <CssBaseline/>
      <Header></Header>
      {!isAuth && <Login></Login>}
      {isAuth && <DisplayPage></DisplayPage>}

    </>
  );
}

export default App;
