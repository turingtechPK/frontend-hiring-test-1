import { configureStore } from '@reduxjs/toolkit';
import { createSlice } from '@reduxjs/toolkit';

const authInitialState = {isAuth: false, token:'-1'};

const authSlice = createSlice({
    name: 'auth',
    initialState: authInitialState, 
    reducers: {
        toggle(state){
        state.isAuth = !state.isAuth;
        },
        setToken(state,action)
        {
            state.token = action.payload;
        }
}
});

const store = configureStore(
    {
        reducer: {auth: authSlice.reducer}
    });
export default store;
export const authAction = authSlice.actions;