import React from "react";
import { Typography, AppBar, CssBaseline, Box, Toolbar, Button } from '@mui/material';
import logo from '../../logo/logo.png';
import { ViewColumn } from "@mui/icons-material";
import { useSelector } from 'react-redux';
import Logout from './Logout';


export default function Header() {
  const isAuth = useSelector(state => state.auth.isAuth);
  return (
    <>
      <AppBar position = 'relative' style={{ background: '#f5f5f5' } }>
        <Toolbar sx = {{display:"flex",
        flexDirection:"row",
        justifyContent:"space-between"
      }}>
          <Box
            component="img"
            sx={{ height: 50}}
            alt="Logo"
            src={logo}
        />
        {isAuth && <Logout></Logout>}
        </Toolbar>
      </AppBar>
    </>
  )
}
