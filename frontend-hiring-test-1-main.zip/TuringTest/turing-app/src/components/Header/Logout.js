import React from 'react'
import { Typography, AppBar, CssBaseline, Box, Toolbar, Button } from '@mui/material'
import { authAction } from '../../store/Redux-Store';
import store from '../../store/Redux-Store';
import { useSelector } from 'react-redux'

export const BTNCOLOR = '#4f46f8';

export default function Logout() {
    const handleLogout = () =>
    {
        store.dispatch(authAction.toggle());
        store.dispatch(authAction.setToken('-1'));
    }
  return (
    <><Button variant="contained" style = {{background: BTNCOLOR}} onClick={handleLogout}>Logout</Button></>
  )
}
