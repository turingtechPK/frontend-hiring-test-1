import * as React from 'react';
import { useState, useEffect } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { useSelector } from 'react-redux';
import { getCalls } from '../../API/App';


// function createData(callType, direction, duration, from, to, via, createdAt, status, ) {
//   return { name, calories, fat, carbs, protein };
// }

// const rows = [
//   createData('Frozen yoghurt', 159, 6.0, 24, 4.0),
//   createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
//   createData('Eclair', 262, 16.0, 24, 6.0),
//   createData('Cupcake', 305, 3.7, 67, 4.3),
//   createData('Gingerbread', 356, 16.0, 49, 3.9),
// ];

export default function CallsTable() {
    const [callsList, setCallsList] = useState([]);
    const token = useSelector(state => state.auth.token);
    const [offSet, setOffSet] = useState(0);
    
    useEffect(() => {
        let mounted = true;
        getCalls({offset: offSet, limit: 100},token)
            .then(items => {
            if(mounted) {
                setCallsList(items.data.nodes);
            }
            })
        return () => mounted = false;
        }, [offSet])
        console.log(callsList);
        const rows = [...callsList];
  return (
        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} size="small" aria-label="a dense table">
        <TableHead>
          <TableRow>
            <TableCell>CALL TYPE</TableCell>
            <TableCell align="center">DIRECTION</TableCell>
            <TableCell align="center">DURATION</TableCell>
            <TableCell align="center">FROM</TableCell>
            <TableCell align="center">TO</TableCell>
            <TableCell align="center">VIA</TableCell>
            <TableCell align="center">CREATED AT</TableCell>
            <TableCell align="center">STATUS</TableCell>
            <TableCell align="center">ACTIONS</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow
              key={row.id}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.call_type}
              </TableCell>
              <TableCell align="center">{row.direction}</TableCell>
              <TableCell align="center">{row.duration}</TableCell>
              <TableCell align="center">{row.from}</TableCell>
              <TableCell align="center">{row.to}</TableCell>
              <TableCell align="center">{row.via}</TableCell>
              <TableCell align="center">{row.created_at}</TableCell>
              {/* <TableCell align="center">{row.is_archived}</TableCell> */}
              {/* <TableCell align="center">{row.protein}</TableCell> */}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
  
}