import React from 'react'
import { Typography, AppBar, CssBaseline, Box, Toolbar, Button, Avatar, TextField,
    FormControlLabel, Checkbox, Copyright, Link, 
    Container } from '@mui/material'
import CallsTable from './CallsTable'
import CallsDataGrid from './CallsDataGrid'
import DisplayInfo from './Notes/DisplayInfo'


export default function DisplayPage() {
  return (
    <>
        <Box m={2} p={3}>
        <Typography variant = 'h5'>Turing Technologies Frontend Test</Typography>
        </Box>
        <CallsDataGrid infoComponent = {DisplayInfo}></CallsDataGrid>
    </>
  )
}
