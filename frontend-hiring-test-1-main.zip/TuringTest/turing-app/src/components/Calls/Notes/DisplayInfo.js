import React from 'react'
import { Typography } from '@mui/material' 
import { BTNCOLOR } from '../../Header/Logout'
import { useState } from 'react';
import { useSelector } from 'react-redux';
import { addNotesofCall } from '../../../API/App';

export default function DisplayInfo(props) {
    const token = useSelector(state => state.auth.token);
    const [note, setNote] = useState('');
    const handleNoteChange = (event) => {
        setNote(event.target.value);
    }
    const handleSubmit = async (event) => {
        event.preventDefault();
        const newnote = await addNotesofCall(props.id, note, token);
        console.log('Note:', note);
        setNote('');
      };
  return (
    <div>

        <Typography variant = 'h6'>Add Notes</Typography>
        <Typography variant = 'h7'>Existing Notes: </Typography>
        <ul>
        {props.notes.map((element) => (
          <li key={element.id}>{element.content}</li>
        ))}
      </ul>
        <p style={{color: BTNCOLOR}}>Call ID {props.id}</p>
        <p>From:  { props.from}</p>
        <p>To: {props.to}</p>
        <p>Via: {props.via}</p>
        <form onSubmit={handleSubmit}>
        <textarea
          value={note}
          onChange={handleNoteChange}
          placeholder="Add Notes"
          rows={4}
          cols={50}
        ></textarea>
        <br />
        <button type="submit">Submit</button>
      </form>
    </div>
  )
}
