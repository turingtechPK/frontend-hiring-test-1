import React from 'react'
import { useState, useEffect } from 'react';
import { Modal, Button } from '@mui/material';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
// import DisplayInfo from './Notes/DisplayInfo';
import { useSelector } from 'react-redux';
import { getCalls } from '../../API/App';
import { BTNCOLOR } from '../Header/Logout';

import { DataGrid } from '@mui/x-data-grid'
export default function CallsDataGrid({ infoComponent: DisplayInfo }) {

    const [isOpen, setIsOpen] = useState(false);
    const [rowInfo, setRowInfo] = useState({});

    const handleClose = () => {
      setIsOpen(false);
    };
    
    const handleCellClick = (params, event) => {
        const rowData = params.row;
        setIsOpen(true);
        setRowInfo(rowData);
      };

    const CustomCell = ({ value }) => (
        <div style={{ color: BTNCOLOR }}>{value}</div>
      );
    const [callsList, setCallsList] = useState([]);
    const token = useSelector(state => state.auth.token);
    const [offSet, setOffSet] = useState(0);
    function isArchived(bool){
        if(bool){
        return 'Archived';}
        else{return 'Unarchived';}
    }
    
    useEffect(() => {
        let mounted = true;
        getCalls({offset: offSet, limit: 999},token)
            .then(items => {
            if(mounted) {
                setCallsList(items.data.nodes);
            }
            })
        return () => mounted = false;
        }, [offSet])
        console.log(callsList);
        const rows = [...callsList];
        const modifiedRows = rows.map(obj => {
            if (obj.is_archived) {
              return { ...obj, is_archived: 'archived' };
            } else {
              return { ...obj, is_archived: 'unarchived' };
            }
          });
        const modifiedRows2 = modifiedRows.map(obj => {
            const alphabetsIndex = obj.created_at.search(/[a-zA-Z]/);
            const modifiedDate = obj.created_at.slice(0, alphabetsIndex);
            
            return { ...obj, created_at: modifiedDate };
        });
    const columns = [
        { field: 'call_type', headerName: 'CALL TYPE' },
        { field: 'direction', headerName: 'DIRECTION' },
        { field: 'duration', hederName: 'DURATION(seconds)' },
        { field: 'from', headerName: 'FROM', width: 150},
        { field: 'to', headerName: 'TO', width: 150},
        { field: 'via', headerName: 'VIA', width: 150},
        { field: 'created_at', headerName: 'CREATED AT', width: 107},
        { field: 'is_archived', headerName: 'STATUS'},
        { field: 'ADD NOTE', headerName: 'ACTION'}
    ]
  return (
    <div>
        <Modal open={isOpen} onClose={handleClose}>
        <div style={{ background: 'white', padding: '20px' }}>
          {DisplayInfo && <DisplayInfo {...rowInfo}/>}
          <Button onClick={handleClose}>Close</Button>
        </div>
      </Modal>
        <DataGrid
    rows={modifiedRows2}
    columns={columns}
    onCellClick={handleCellClick}
    initialState={{
      pagination: {
        paginationModel: { page: 0, pageSize: 6 },
      },
    }}
    pageSizeOptions={[10]}
  />
  </div>
  )
}

